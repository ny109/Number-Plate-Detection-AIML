import os
import cv2
import tkinter as tk
from tkinter import filedialog, ttk, messagebox
from PIL import Image, ImageTk
import numpy as np
import threading
import warnings
import torch
import pandas as pd
from license_plate_detector import LicensePlateDetector

warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=FutureWarning)

# === Local CSV Database ===
database_data = {
    "License Plate": ["HR26FD9951", "HR26EK1294", "HR26FK3074", "DL12SE9822", "HR26FB5523", "DL55SK6634","MH12DE1433","MZ01T5186"],
    "Owner Name": ["JOJO P JOY", "NARENDRA", "KSHITIJ", "VIRENDRA", "DANIEL", "JACK", "SURAJ","FUNSUK WAGDU"],
    "Vehicle Model": ["TVS NTORQ", "BREEZA", "RE GT650", "RE BULLET", "NS 200", "CIAZ","FORD","SUZUKI"],
    "Ticket Pending": ["NO", "YES", "NO", "YES", "YES", "YES","YES","NO"],
    "Pollution Verification": ["YES", "YES", "YES", "YES", "YES", "NO","YES","YES"]
}
vehicle_df = pd.DataFrame(database_data)

# === License Plate Detection with Webcam ===
harcascade = r"D:\major project\haarcascade_russian_plate_number.xml"
output_dir = "plates"

if not os.path.exists(output_dir):
    os.makedirs(output_dir)

plate_cascade = cv2.CascadeClassifier(harcascade)
if plate_cascade.empty():
    raise IOError("Haarcascade XML could not be loaded. Check the path.")

cap = cv2.VideoCapture(0)
cap.set(3, 640)
cap.set(4, 480)

min_area = 500
count = 0

while True:
    success, img = cap.read()
    if not success:
        break

    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    plates = plate_cascade.detectMultiScale(img_gray, 1.1, 4)

    for (x, y, w, h) in plates:
        area = w * h
        if area > min_area:
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(img, "Number Plate", (x, y - 5), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (255, 0, 255), 2)
            img_roi = img[y: y + h, x:x + w]
            cv2.imshow("ROI", img_roi)

    cv2.imshow("Result", img)

    key = cv2.waitKey(1) & 0xFF
    if key == ord('s'):
        if 'img_roi' in locals():
            cv2.imwrite(f"{output_dir}/scanned_img_{count}.jpg", img_roi)
            cv2.rectangle(img, (0, 200), (640, 300), (0, 255, 0), cv2.FILLED)
            cv2.putText(img, "Plate Saved", (150, 265), cv2.FONT_HERSHEY_COMPLEX_SMALL, 2, (0, 0, 255), 2)
            cv2.imshow("Result", img)
            cv2.waitKey(500)
            count += 1
    elif key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

print("Camera closed. Proceeding to GUI...")

# === GUI: Upload and Detect Plate from Images ===
class LicensePlateApp:
    def __init__(self, root):
        self.root = root
        self.root.title("License Plate Detector")
        self.root.geometry("800x600")

        self.detector_ready = threading.Event()
        self.upload_btn = None

        self.loading_label = ttk.Label(self.root, text="Initializing... Please wait", font=('Arial', 12))
        self.loading_label.grid(row=0, column=0, pady=10)
        self.root.update()

        self.main_frame = ttk.Frame(root, padding="10")
        self.main_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.upload_btn = ttk.Button(self.main_frame, text="Upload Image", command=self.upload_image, state='disabled')
        self.upload_btn.grid(row=0, column=0, pady=10)

        self.image_label = ttk.Label(self.main_frame)
        self.image_label.grid(row=1, column=0, pady=10)

        self.plate_label = ttk.Label(self.main_frame)
        self.plate_label.grid(row=2, column=0, pady=10)

        self.result_label = ttk.Label(self.main_frame, text="Upload an image to begin", font=('Arial', 12))
        self.result_label.grid(row=3, column=0, pady=10)

        threading.Thread(target=self.initialize_detector, daemon=True).start()

    def initialize_detector(self):
        try:
            torch.set_grad_enabled(False)
            torch.set_default_dtype(torch.float32)

            self.detector = LicensePlateDetector()
            self.detector_ready.set()

            self.root.after(0, self._initialization_complete)
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Initialization Error", f"Failed to initialize detector: {str(e)}"))
            self.root.after(0, self.root.quit)

    def _initialization_complete(self):
        self.loading_label.destroy()
        self.upload_btn.configure(state='normal')

    def upload_image(self):
        if not self.detector_ready.is_set():
            messagebox.showinfo("Please Wait", "Detector is still initializing...")
            return

        file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png *.jpg *.jpeg")])
        if not file_path:
            return

        try:
            image = Image.open(file_path)
            image = image.resize((400, 300), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(image)
            self.image_label.configure(image=photo)
            self.image_label.image = photo

            self.result_label.configure(text="Processing image... Please wait")
            self.root.update()

            def process_image():
                try:
                    plate_image, plate_text = self.detector.detect_plate(file_path)

                    if plate_image is not None and plate_text:
                        plate_image_pil = Image.fromarray(plate_image)
                        plate_image_pil = plate_image_pil.resize((200, 100), Image.Resampling.LANCZOS)
                        plate_photo = ImageTk.PhotoImage(plate_image_pil)

                        self.root.after(0, lambda: self.plate_label.configure(image=plate_photo))
                        self.root.after(0, lambda: setattr(self.plate_label, 'image', plate_photo))

                        # Check if the license plate exists in the database
                        matched_row = vehicle_df[vehicle_df["License Plate"] == plate_text.strip().upper()]
                        if not matched_row.empty:
                            owner_info = matched_row.iloc[0]
                            info = (
                                f"Plate: {owner_info['License Plate']}\n"
                                f"Owner: {owner_info['Owner Name']}\n"
                                f"Model: {owner_info['Vehicle Model']}\n"
                                f"Ticket Pending: {owner_info['Ticket Pending']}\n"
                                f"Pollution Check: {owner_info['Pollution Verification']}"
                            )
                            self.root.after(0, lambda: self.result_label.configure(text=info))
                        else:
                            self.root.after(0, lambda: self.result_label.configure(text=f"Detected Plate: {plate_text}\nNOT FOUND in Database"))
                    else:
                        self.root.after(0, lambda: self.plate_label.configure(image=''))
                        self.root.after(0, lambda: self.result_label.configure(text="No license plate detected"))
                except Exception as e:
                    messagebox.showerror("Processing Error", f"Error processing image: {str(e)}")
                    self.result_label.configure(text="Error processing image")

            threading.Thread(target=process_image).start()

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
            print(f"Error details: {str(e)}")

def main():
    root = tk.Tk()
    app = LicensePlateApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
